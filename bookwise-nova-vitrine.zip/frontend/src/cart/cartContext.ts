import { createContext } from 'react';
import type { Book } from '../types/api';

export interface CartItem {
  bookId: number;
  title: string;
  author: string;
  price: number;
  isbn?: string;
  coverUrl?: string;
  quantity: number;
  /** Estoque conhecido quando o livro entrou na sacola; limita a quantidade. */
  stock?: number;
}

export type AddResult = 'added' | 'limit' | 'unavailable';

export interface CartContextValue {
  items: CartItem[];
  count: number;
  subtotal: number;
  isOpen: boolean;
  /** Sobe a cada compra concluida; paginas observam para recarregar o estoque. */
  purchaseVersion: number;
  notifyPurchase: () => void;
  open: () => void;
  close: () => void;
  add: (book: Book, quantity?: number) => AddResult;
  setQuantity: (bookId: number, quantity: number) => void;
  remove: (bookId: number) => void;
  clear: () => void;
}

export const CartContext = createContext<CartContextValue | undefined>(undefined);
