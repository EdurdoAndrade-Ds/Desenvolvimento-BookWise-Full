import { useCallback, useEffect, useMemo, useState, type ReactNode } from 'react';
import type { Book } from '../types/api';
import { CartContext, type AddResult, type CartItem } from './cartContext';

const STORAGE_KEY = 'bookwise-cart';

function isCartItem(value: unknown): value is CartItem {
  if (typeof value !== 'object' || value === null) return false;
  const item = value as Record<string, unknown>;
  return (
    typeof item.bookId === 'number' &&
    typeof item.title === 'string' &&
    typeof item.author === 'string' &&
    typeof item.price === 'number' &&
    typeof item.quantity === 'number' &&
    item.quantity > 0
  );
}

/** Le a sacola salva; qualquer dado ausente, corrompido ou inacessivel vira sacola vazia. */
function readStored(): CartItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    const parsed: unknown = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed.filter(isCartItem) : [];
  } catch {
    return [];
  }
}

function clampQuantity(quantity: number, stock?: number): number {
  const whole = Math.max(1, Math.floor(quantity));
  return stock !== undefined && stock > 0 ? Math.min(whole, stock) : whole;
}

/**
 * Sacola do portal do cliente. Vive apenas no navegador: a API so e chamada no
 * fechamento, reaproveitando o endpoint de vendas ja existente.
 */
export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>(readStored);
  const [isOpen, setIsOpen] = useState(false);
  const [purchaseVersion, setPurchaseVersion] = useState(0);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
    } catch {
      // armazenamento indisponivel: a sacola segue funcionando em memoria
    }
  }, [items]);

  const add = useCallback(
    (book: Book, quantity = 1): AddResult => {
      if (book.price === undefined || book.price <= 0 || (book.stock ?? 0) <= 0) {
        return 'unavailable';
      }
      const existing = items.find((item) => item.bookId === book.id);
      const wanted = (existing?.quantity ?? 0) + quantity;
      const next = clampQuantity(wanted, book.stock);
      if (existing && next === existing.quantity) return 'limit';

      setItems((current) => {
        const entry: CartItem = {
          bookId: book.id,
          title: book.title,
          author: book.author,
          price: book.price as number,
          isbn: book.isbn,
          coverUrl: book.coverUrl,
          quantity: next,
          stock: book.stock,
        };
        return current.some((item) => item.bookId === book.id)
          ? current.map((item) => (item.bookId === book.id ? entry : item))
          : [...current, entry];
      });
      return 'added';
    },
    [items],
  );

  const setQuantity = useCallback((bookId: number, quantity: number) => {
    setItems((current) =>
      quantity < 1
        ? current.filter((item) => item.bookId !== bookId)
        : current.map((item) =>
            item.bookId === bookId
              ? { ...item, quantity: clampQuantity(quantity, item.stock) }
              : item,
          ),
    );
  }, []);

  const remove = useCallback(
    (bookId: number) => setItems((current) => current.filter((item) => item.bookId !== bookId)),
    [],
  );
  const clear = useCallback(() => setItems([]), []);
  const notifyPurchase = useCallback(() => setPurchaseVersion((version) => version + 1), []);
  const open = useCallback(() => setIsOpen(true), []);
  const close = useCallback(() => setIsOpen(false), []);

  const value = useMemo(
    () => ({
      items,
      count: items.reduce((total, item) => total + item.quantity, 0),
      subtotal: items.reduce((total, item) => total + item.price * item.quantity, 0),
      isOpen,
      purchaseVersion,
      notifyPurchase,
      open,
      close,
      add,
      setQuantity,
      remove,
      clear,
    }),
    [items, isOpen, purchaseVersion, notifyPurchase, open, close, add, setQuantity, remove, clear],
  );

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}
