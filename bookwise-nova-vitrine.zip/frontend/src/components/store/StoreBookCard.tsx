import { ShoppingBag, Box } from 'lucide-react';
import BookCover from '../BookCover';
import type { Book } from '../../types/api';
import { formatCurrency } from '../../lib/format';
import { installmentsOf, isPurchasable, type Badge } from '../../lib/storefront';

interface StoreBookCardProps {
  book: Book;
  badge?: Badge | null;
  /** Motivo da indicacao, exibido na secao "Para voce". */
  reason?: string;
  onAdd: (book: Book) => void;
  onView3D: (book: Book) => void;
}

export default function StoreBookCard({
  book,
  badge,
  reason,
  onAdd,
  onView3D,
}: StoreBookCardProps) {
  const installments = installmentsOf(book.price);
  const soldOut = (book.stock ?? 0) <= 0;
  const purchasable = isPurchasable(book);

  return (
    <article className="group flex h-full flex-col rounded-2xl border border-rule bg-paper-card p-4 shadow-sm transition hover:-translate-y-1 hover:shadow-lg">
      <button
        type="button"
        onClick={() => onView3D(book)}
        aria-label={`Ver ${book.title} em 3D`}
        className="relative block w-full rounded-xl focus:outline-none focus-visible:ring-2 focus-visible:ring-gold"
      >
        <BookCover
          book={book}
          className="aspect-[3/4] w-full rounded-xl bg-paper-deep shadow-md"
          iconClassName="h-12 w-12"
          imageClassName="transition duration-300 group-hover:scale-[1.03]"
        />
        {badge ? (
          <span className="absolute left-2 top-2 rounded-full bg-cabinet px-2.5 py-1 text-[0.65rem] font-semibold uppercase tracking-wider text-[#f6f3ec]">
            {badge}
          </span>
        ) : null}
        {soldOut ? (
          <span className="absolute right-2 top-2 rounded-full bg-wine px-2.5 py-1 text-[0.65rem] font-semibold uppercase tracking-wider text-white">
            Esgotado
          </span>
        ) : null}
      </button>

      <div className="mt-4 flex flex-1 flex-col">
        <p className="line-clamp-1 text-xs uppercase tracking-[0.14em] text-ink-soft">
          {book.author}
        </p>
        <h3 className="mt-1 line-clamp-2 font-serif text-lg leading-snug text-ink">{book.title}</h3>
        {reason ? <p className="mt-2 text-xs italic text-ink-soft">{reason}</p> : null}

        <div className="mt-3">
          <p className="font-serif text-xl text-ink">
            {book.price !== undefined ? formatCurrency(book.price) : 'Preço sob consulta'}
          </p>
          {installments ? (
            <p className="text-xs text-ink-soft">
              ou {installments.count}x de {formatCurrency(installments.value)} sem juros
            </p>
          ) : null}
        </div>

        <div className="mt-auto flex flex-col gap-2 pt-4">
          <button
            type="button"
            disabled={!purchasable}
            onClick={() => onAdd(book)}
            className="inline-flex items-center justify-center gap-2 rounded-md bg-cabinet px-3 py-2.5 text-sm font-semibold text-[#f6f3ec] transition hover:bg-[#3b2f26] focus:outline-none focus-visible:ring-2 focus-visible:ring-gold disabled:cursor-not-allowed disabled:opacity-40"
          >
            <ShoppingBag className="h-4 w-4" />
            {soldOut ? 'Indisponível' : 'Adicionar à sacola'}
          </button>
          <button
            type="button"
            onClick={() => onView3D(book)}
            className="inline-flex items-center justify-center gap-2 rounded-md border border-rule px-3 py-2 text-sm font-medium text-ink transition hover:bg-paper-deep focus:outline-none focus-visible:ring-2 focus-visible:ring-gold"
          >
            <Box className="h-4 w-4" />
            Ver em 3D
          </button>
        </div>
      </div>
    </article>
  );
}
