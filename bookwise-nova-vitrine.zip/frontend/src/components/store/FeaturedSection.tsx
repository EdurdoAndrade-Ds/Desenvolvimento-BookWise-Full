import { useMemo, useState } from 'react';
import type { Book } from '../../types/api';
import SectionHeader from './SectionHeader';
import StoreBookCard from './StoreBookCard';
import { newestFirst, type Badge } from '../../lib/storefront';

type Tab = 'popular' | 'latest';
const SHOWN = 5;

interface FeaturedSectionProps {
  /** Ja ordenados por procura (emprestimos), quando o relatorio esta disponivel. */
  popular: Book[];
  books: Book[];
  badgeOf: (book: Book) => Badge | null;
  onAdd: (book: Book) => void;
  onView3D: (book: Book) => void;
}

export default function FeaturedSection({
  popular,
  books,
  badgeOf,
  onAdd,
  onView3D,
}: FeaturedSectionProps) {
  const [tab, setTab] = useState<Tab>('popular');
  const latest = useMemo(() => newestFirst(books), [books]);
  const shown = (tab === 'popular' ? popular : latest).slice(0, SHOWN);

  if (books.length === 0) return null;

  return (
    <section
      id="destaques"
      aria-labelledby="destaques-title"
      className="mx-auto max-w-7xl scroll-mt-24 px-4 py-20 sm:px-6"
    >
      <SectionHeader
        index="03"
        label="Destaques"
        aside={
          <div
            role="tablist"
            aria-label="Tipo de destaque"
            className="flex rounded-full border border-rule p-1"
          >
            {(
              [
                ['popular', 'Mais procurados'],
                ['latest', 'Lançamentos'],
              ] as [Tab, string][]
            ).map(([id, label]) => (
              <button
                key={id}
                role="tab"
                type="button"
                aria-selected={tab === id}
                onClick={() => setTab(id)}
                className={`rounded-full px-4 py-2 text-sm transition ${
                  tab === id ? 'bg-cabinet text-[#f6f3ec]' : 'text-ink-soft hover:text-ink'
                }`}
              >
                {label}
              </button>
            ))}
          </div>
        }
      >
        <span id="destaques-title">
          O que anda <em>nas mãos</em> dos leitores.
        </span>
      </SectionHeader>

      <ul className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-5">
        {shown.map((book) => (
          <li key={book.id}>
            <StoreBookCard book={book} badge={badgeOf(book)} onAdd={onAdd} onView3D={onView3D} />
          </li>
        ))}
      </ul>
    </section>
  );
}
