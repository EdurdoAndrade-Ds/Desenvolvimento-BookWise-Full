import { Link } from 'react-router-dom';
import { ArrowDown } from 'lucide-react';

export default function HeroSection() {
  return (
    <section
      aria-labelledby="hero-title"
      className="relative overflow-hidden border-b border-rule bg-gradient-to-b from-paper-deep to-paper"
    >
      <div className="mx-auto max-w-4xl px-4 py-20 text-center sm:px-6 sm:py-28">
        <p className="text-xs font-semibold uppercase tracking-[0.3em] text-gold-deep">
          Livraria · desde as primeiras páginas
        </p>
        <h1
          id="hero-title"
          className="mt-6 font-serif text-5xl leading-[1.05] text-ink sm:text-6xl lg:text-7xl [&_em]:italic [&_em]:text-gold-deep"
        >
          Cada livro é um universo. <em className="whitespace-nowrap">Explore-o</em> por inteiro.
        </h1>
        <p className="mx-auto mt-6 max-w-xl text-base text-ink-soft sm:text-lg">
          Clássicos e contemporâneos escolhidos com cuidado. Antes de levar, examine capa, lombada e
          páginas em três dimensões.
        </p>
        <div className="mt-9 flex flex-wrap items-center justify-center gap-3">
          <Link
            to={{ pathname: '/', hash: '#biblioteca' }}
            className="rounded-md bg-cabinet px-6 py-3 text-sm font-semibold text-[#f6f3ec] transition hover:bg-[#3b2f26]"
          >
            Explorar biblioteca
          </Link>
          <Link
            to={{ pathname: '/', hash: '#visualizador' }}
            className="rounded-md border border-ink/25 px-6 py-3 text-sm font-semibold text-ink transition hover:bg-paper-deep"
          >
            Descobrir livros em 3D
          </Link>
        </div>
        <div className="mt-14 flex flex-col items-center gap-2 text-ink-soft">
          <span aria-hidden="true" className="font-serif text-3xl text-gold">
            §
          </span>
          <Link
            to={{ pathname: '/', hash: '#visualizador' }}
            className="inline-flex items-center gap-2 text-xs italic"
          >
            gire-os no gabinete abaixo <ArrowDown className="h-3.5 w-3.5" />
          </Link>
        </div>
      </div>
    </section>
  );
}
