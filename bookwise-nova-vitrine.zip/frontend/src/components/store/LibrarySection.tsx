import { useMemo, useState } from 'react';
import { Search } from 'lucide-react';
import type { Book, Category } from '../../types/api';
import SectionHeader from './SectionHeader';
import StoreBookCard from './StoreBookCard';
import { PRICE_CAP, filterBooks, sortBooks, type Badge, type SortKey } from '../../lib/storefront';
import { formatCurrency } from '../../lib/format';

const PAGE_STEP = 12;

interface LibrarySectionProps {
  books: Book[];
  categories: Category[];
  query: string;
  categoryId: string;
  onQueryChange: (value: string) => void;
  onCategoryChange: (value: string) => void;
  badgeOf: (book: Book) => Badge | null;
  onAdd: (book: Book) => void;
  onView3D: (book: Book) => void;
}

const FIELD =
  'w-full rounded-md border border-rule bg-paper-card px-3 py-2.5 text-sm text-ink outline-none focus:border-gold';

export default function LibrarySection({
  books,
  categories,
  query,
  categoryId,
  onQueryChange,
  onCategoryChange,
  badgeOf,
  onAdd,
  onView3D,
}: LibrarySectionProps) {
  const [sort, setSort] = useState<SortKey>('relevance');
  const [underCap, setUnderCap] = useState(false);
  const [inStock, setInStock] = useState(false);
  const [visible, setVisible] = useState(PAGE_STEP);

  const results = useMemo(
    () => sortBooks(filterBooks(books, { query, categoryId, underCap, inStock }), sort),
    [books, query, categoryId, underCap, inStock, sort],
  );

  // Qualquer mudanca de filtro volta a lista ao tamanho inicial.
  const resetPaging = () => setVisible(PAGE_STEP);

  return (
    <section
      id="biblioteca"
      aria-labelledby="biblioteca-title"
      className="scroll-mt-24 border-y border-rule bg-paper-deep"
    >
      <div className="mx-auto max-w-7xl px-4 py-20 sm:px-6">
        <SectionHeader index="04" label="Biblioteca">
          <span id="biblioteca-title">
            Toda a coleção, <em>à sua maneira.</em>
          </span>
        </SectionHeader>

        <form
          role="search"
          onSubmit={(event) => event.preventDefault()}
          className="mt-10 grid gap-4 md:grid-cols-[2fr_1fr_1fr]"
        >
          <label className="block text-xs font-semibold uppercase tracking-[0.15em] text-ink-soft">
            Busca
            <span className="relative mt-2 block">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-soft" />
              <input
                value={query}
                onChange={(event) => {
                  onQueryChange(event.target.value);
                  resetPaging();
                }}
                placeholder="Título, autor ou categoria"
                className={`${FIELD} pl-9 font-normal normal-case tracking-normal`}
              />
            </span>
          </label>
          <label className="block text-xs font-semibold uppercase tracking-[0.15em] text-ink-soft">
            Categoria
            <select
              value={categoryId}
              onChange={(event) => {
                onCategoryChange(event.target.value);
                resetPaging();
              }}
              className={`${FIELD} mt-2 font-normal normal-case tracking-normal`}
            >
              <option value="">Todas</option>
              {categories.map((category) => (
                <option key={category.id} value={category.id}>
                  {category.name}
                </option>
              ))}
            </select>
          </label>
          <label className="block text-xs font-semibold uppercase tracking-[0.15em] text-ink-soft">
            Ordenar
            <select
              value={sort}
              onChange={(event) => setSort(event.target.value as SortKey)}
              className={`${FIELD} mt-2 font-normal normal-case tracking-normal`}
            >
              <option value="relevance">Relevância</option>
              <option value="price-asc">Menor preço</option>
              <option value="price-desc">Maior preço</option>
            </select>
          </label>
        </form>

        <div className="mt-4 flex flex-wrap gap-3">
          {(
            [
              [`Até ${formatCurrency(PRICE_CAP).replace(',00', '')}`, underCap, setUnderCap],
              ['Em estoque', inStock, setInStock],
            ] as [string, boolean, (value: boolean) => void][]
          ).map(([label, active, set]) => (
            <button
              key={label}
              type="button"
              aria-pressed={active}
              onClick={() => {
                set(!active);
                resetPaging();
              }}
              className={`rounded-full border px-4 py-2 text-sm transition ${
                active
                  ? 'border-cabinet bg-cabinet text-[#f6f3ec]'
                  : 'border-rule text-ink hover:bg-paper-card'
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        <p role="status" className="mt-6 text-sm text-ink-soft">
          {results.length} {results.length === 1 ? 'livro encontrado' : 'livros encontrados'}.
        </p>

        {results.length === 0 ? (
          <p className="mt-6 rounded-2xl border border-dashed border-rule p-12 text-center text-ink-soft">
            Nenhum livro encontrado. Tente outros termos ou limpe os filtros.
          </p>
        ) : (
          <>
            <ul className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
              {results.slice(0, visible).map((book) => (
                <li key={book.id}>
                  <StoreBookCard
                    book={book}
                    badge={badgeOf(book)}
                    onAdd={onAdd}
                    onView3D={onView3D}
                  />
                </li>
              ))}
            </ul>
            {visible < results.length ? (
              <div className="mt-10 text-center">
                <button
                  type="button"
                  onClick={() => setVisible((value) => value + PAGE_STEP)}
                  className="rounded-md border border-ink/25 px-6 py-3 text-sm font-semibold text-ink hover:bg-paper-card"
                >
                  Mostrar mais livros
                </button>
              </div>
            ) : null}
          </>
        )}
      </div>
    </section>
  );
}
