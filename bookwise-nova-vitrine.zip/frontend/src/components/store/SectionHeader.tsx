import type { ReactNode } from 'react';

interface SectionHeaderProps {
  index: string;
  label: string;
  children: ReactNode;
  aside?: ReactNode;
}

/** Cabecalho de secao: numero em romano/arabe, rotulo e titulo serifado com destaque em italico. */
export default function SectionHeader({ index, label, children, aside }: SectionHeaderProps) {
  return (
    <div className="flex flex-wrap items-end justify-between gap-4">
      <div>
        <p className="flex items-center gap-3 text-xs font-semibold uppercase tracking-[0.25em] text-gold-deep">
          <span className="font-serif text-base tracking-normal text-gold">{index}</span>
          <span aria-hidden="true" className="h-px w-8 bg-gold/60" />
          {label}
        </p>
        <h2 className="mt-3 max-w-2xl font-serif text-3xl leading-tight text-ink sm:text-4xl [&_em]:italic [&_em]:text-gold-deep">
          {children}
        </h2>
      </div>
      {aside}
    </div>
  );
}
