import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Minus, Plus, Trash2, X } from 'lucide-react';
import BookCover from '../BookCover';
import { useCart } from '../../cart/useCart';
import { useCurrentCustomer } from '../../context/useCurrentCustomer';
import { salesService } from '../../services/salesService';
import { ApiError } from '../../services/http';
import { formatCurrency } from '../../lib/format';
import { FREE_SHIPPING_THRESHOLD } from '../../lib/storefront';

/**
 * Sacola em gaveta lateral. O fechamento cria uma unica venda pelo endpoint
 * existente (POST /api/v1/sales); precos e estoque continuam sendo validados pela API.
 */
export default function CartDrawer() {
  const { items, subtotal, isOpen, close, setQuantity, remove, clear, notifyPurchase } = useCart();
  const { customer } = useCurrentCustomer();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState<string | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') close();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [isOpen, close]);

  useEffect(() => {
    if (!isOpen) {
      setError(null);
      setDone(null);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const missing = Math.max(0, FREE_SHIPPING_THRESHOLD - subtotal);
  const progress = Math.min(100, (subtotal / FREE_SHIPPING_THRESHOLD) * 100);

  const checkout = async () => {
    if (!customer) {
      setError('Selecione um cliente em “Minha área” para finalizar a compra.');
      return;
    }
    setBusy(true);
    setError(null);
    try {
      await salesService.create({
        userId: customer.id,
        paymentMethod: 'Portal',
        items: items.map((item) => ({ bookId: item.bookId, quantity: item.quantity })),
      });
      clear();
      notifyPurchase();
      setDone('Compra realizada com sucesso.');
    } catch (err) {
      setError(
        err instanceof ApiError && err.status === 409
          ? 'Não há estoque suficiente para um dos livros da sacola.'
          : err instanceof ApiError
            ? err.message
            : 'Não foi possível concluir a compra.',
      );
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50" role="dialog" aria-modal="true" aria-label="Sacola">
      <button
        type="button"
        aria-label="Fechar sacola"
        onClick={close}
        className="absolute inset-0 bg-black/50 backdrop-blur-sm"
      />
      <aside className="absolute inset-y-0 right-0 flex w-full max-w-md flex-col bg-paper shadow-2xl">
        <div className="flex items-center justify-between border-b border-rule px-6 py-5">
          <h2 className="font-serif text-2xl text-ink">Sua sacola</h2>
          <button
            type="button"
            onClick={close}
            aria-label="Fechar sacola"
            className="rounded-full p-2 text-ink-soft hover:bg-paper-deep"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {done ? (
          <div className="flex flex-1 flex-col items-center justify-center gap-4 px-8 text-center">
            <p className="font-serif text-2xl text-ink">{done}</p>
            <p className="text-sm text-ink-soft">Você pode acompanhar o pedido em Compras.</p>
            <Link
              to="/my-purchases"
              onClick={close}
              className="rounded-md bg-cabinet px-5 py-2.5 text-sm font-semibold text-[#f6f3ec] hover:bg-[#3b2f26]"
            >
              Ver minhas compras
            </Link>
          </div>
        ) : items.length === 0 ? (
          <div className="flex flex-1 flex-col items-center justify-center gap-3 px-8 text-center">
            <p className="font-serif text-2xl text-ink">A sacola está vazia.</p>
            <p className="text-sm text-ink-soft">Escolha um livro e ele aparece aqui.</p>
            <button
              type="button"
              onClick={close}
              className="mt-2 rounded-md border border-rule px-5 py-2.5 text-sm font-semibold text-ink hover:bg-paper-deep"
            >
              Continuar explorando
            </button>
          </div>
        ) : (
          <>
            <div className="border-b border-rule px-6 py-4">
              <p className="text-xs text-ink-soft">
                {missing > 0
                  ? `Faltam ${formatCurrency(missing)} para o frete grátis.`
                  : 'Você ganhou frete grátis.'}
              </p>
              <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-paper-deep">
                <div className="h-full rounded-full bg-gold" style={{ width: `${progress}%` }} />
              </div>
            </div>

            <ul className="flex-1 divide-y divide-rule overflow-y-auto px-6">
              {items.map((item) => (
                <li key={item.bookId} className="flex gap-4 py-4">
                  <BookCover
                    book={{ title: item.title, isbn: item.isbn ?? '', coverUrl: item.coverUrl }}
                    className="h-24 w-16 shrink-0 rounded-md shadow"
                    iconClassName="h-6 w-6"
                  />
                  <div className="min-w-0 flex-1">
                    <p className="line-clamp-2 font-serif text-base leading-snug text-ink">
                      {item.title}
                    </p>
                    <p className="text-xs text-ink-soft">{item.author}</p>
                    <div className="mt-3 flex items-center justify-between">
                      <div className="inline-flex items-center rounded-md border border-rule">
                        <button
                          type="button"
                          aria-label={`Diminuir quantidade de ${item.title}`}
                          onClick={() => setQuantity(item.bookId, item.quantity - 1)}
                          className="p-2 text-ink hover:bg-paper-deep"
                        >
                          <Minus className="h-3.5 w-3.5" />
                        </button>
                        <span className="min-w-8 text-center text-sm text-ink" aria-live="polite">
                          {item.quantity}
                        </span>
                        <button
                          type="button"
                          aria-label={`Aumentar quantidade de ${item.title}`}
                          disabled={item.stock !== undefined && item.quantity >= item.stock}
                          onClick={() => setQuantity(item.bookId, item.quantity + 1)}
                          className="p-2 text-ink hover:bg-paper-deep disabled:opacity-30"
                        >
                          <Plus className="h-3.5 w-3.5" />
                        </button>
                      </div>
                      <p className="font-serif text-base text-ink">
                        {formatCurrency(item.price * item.quantity)}
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    aria-label={`Remover ${item.title}`}
                    onClick={() => remove(item.bookId)}
                    className="self-start rounded-full p-2 text-ink-soft hover:bg-paper-deep hover:text-wine"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </li>
              ))}
            </ul>

            <div className="border-t border-rule bg-paper-card px-6 py-5">
              <div className="flex items-baseline justify-between">
                <span className="text-sm text-ink-soft">Subtotal</span>
                <span className="font-serif text-2xl text-ink">{formatCurrency(subtotal)}</span>
              </div>
              {error ? (
                <p className="mt-3 rounded-md bg-[#f6e7e2] px-3 py-2 text-xs text-[#8a3a27] dark:bg-red-950/40 dark:text-red-300">
                  {error}
                </p>
              ) : null}
              <button
                type="button"
                disabled={busy}
                onClick={() => void checkout()}
                className="mt-4 w-full rounded-md bg-cabinet px-4 py-3 text-sm font-semibold text-[#f6f3ec] hover:bg-[#3b2f26] disabled:opacity-50"
              >
                {busy ? 'Processando...' : 'Finalizar compra'}
              </button>
              <button
                type="button"
                onClick={close}
                className="mt-2 w-full py-2 text-xs text-ink-soft underline-offset-2 hover:underline"
              >
                Continuar explorando
              </button>
            </div>
          </>
        )}
      </aside>
    </div>
  );
}
