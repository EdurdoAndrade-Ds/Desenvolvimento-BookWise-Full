import { Link } from 'react-router-dom';
import { BrandMark } from './StoreHeader';
import type { Category } from '../../types/api';

const INSTITUTIONAL = ['Sobre nós', 'Curadoria', 'Trabalhe conosco', 'Imprensa'];
const HELP: { label: string; to: string }[] = [
  { label: 'Minha conta', to: '/my-account' },
  { label: 'Entregas e prazos', to: '/' },
  { label: 'Trocas e devoluções', to: '/' },
  { label: 'Fale conosco', to: '/' },
];
const PAYMENTS = ['Pix', 'Visa', 'Mastercard', 'Elo', 'Boleto'];

export default function StoreFooter({ categories }: { categories: Category[] }) {
  return (
    <footer className="border-t border-rule bg-paper-deep">
      <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6">
        <div className="grid gap-10 md:grid-cols-[1.4fr_1fr_1fr_1fr]">
          <div>
            <BrandMark />
            <p className="mt-3 max-w-xs text-sm text-ink-soft">
              Uma biblioteca clássica, reinterpretada para quem lê hoje.
            </p>
          </div>
          <div>
            <h3 className="font-serif text-lg text-ink">Institucional</h3>
            <ul className="mt-3 space-y-2 text-sm text-ink-soft">
              {INSTITUTIONAL.map((label) => (
                <li key={label}>
                  <Link to="/" className="hover:text-ink">
                    {label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h3 className="font-serif text-lg text-ink">Ajuda</h3>
            <ul className="mt-3 space-y-2 text-sm text-ink-soft">
              {HELP.map((item) => (
                <li key={item.label}>
                  <Link to={item.to} className="hover:text-ink">
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h3 className="font-serif text-lg text-ink">Categorias</h3>
            <ul className="mt-3 space-y-2 text-sm text-ink-soft">
              {categories.slice(0, 8).map((category) => (
                <li key={category.id}>
                  <Link
                    to={{ pathname: '/', search: `?categoria=${category.id}`, hash: '#biblioteca' }}
                    className="hover:text-ink"
                  >
                    {category.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-12 flex flex-wrap items-center justify-between gap-4 border-t border-rule pt-6">
          <ul className="flex flex-wrap gap-2" aria-label="Formas de pagamento">
            {PAYMENTS.map((name) => (
              <li
                key={name}
                className="rounded border border-rule px-2.5 py-1 text-[0.7rem] font-semibold uppercase tracking-wider text-ink-soft"
              >
                {name}
              </li>
            ))}
          </ul>
          <p className="max-w-xl text-xs text-ink-soft">
            Preços e condições válidos para compras no site, sujeitos à disponibilidade de estoque.
          </p>
        </div>
      </div>
    </footer>
  );
}
