import { useMemo, useState } from 'react';
import { Check } from 'lucide-react';
import type { Book } from '../../types/api';
import SectionHeader from './SectionHeader';
import StoreBookCard from './StoreBookCard';
import {
  DEFAULT_INTERESTS,
  INTERESTS,
  MAX_INTERESTS,
  MIN_INTERESTS,
  recommend,
  type Badge,
} from '../../lib/storefront';

interface ForYouSectionProps {
  books: Book[];
  badgeOf: (book: Book) => Badge | null;
  onAdd: (book: Book) => void;
  onView3D: (book: Book) => void;
}

export default function ForYouSection({ books, badgeOf, onAdd, onView3D }: ForYouSectionProps) {
  const [selected, setSelected] = useState<string[]>(DEFAULT_INTERESTS);
  const picks = useMemo(() => recommend(books, selected), [books, selected]);

  const toggle = (id: string) =>
    setSelected((current) =>
      current.includes(id)
        ? current.filter((item) => item !== id)
        : current.length >= MAX_INTERESTS
          ? current
          : [...current, id],
    );

  return (
    <section
      id="para-voce"
      aria-labelledby="para-voce-title"
      className="mx-auto max-w-7xl scroll-mt-24 px-4 py-20 sm:px-6"
    >
      <SectionHeader index="05" label="Para você">
        <span id="para-voce-title">
          Diga o que procura. <em>Nós indicamos.</em>
        </span>
      </SectionHeader>
      <p className="mt-4 text-ink-soft">
        Escolha de {MIN_INTERESTS} a {MAX_INTERESTS} interesses. As sugestões se reorganizam na
        hora.
      </p>

      <fieldset className="mt-8">
        <legend className="text-xs font-semibold uppercase tracking-[0.18em] text-ink-soft">
          Interesses de leitura
        </legend>
        <ul className="mt-4 flex flex-wrap gap-3">
          {INTERESTS.map((interest) => {
            const active = selected.includes(interest.id);
            const blocked = !active && selected.length >= MAX_INTERESTS;
            return (
              <li key={interest.id}>
                <button
                  type="button"
                  aria-pressed={active}
                  disabled={blocked}
                  onClick={() => toggle(interest.id)}
                  className={`inline-flex items-center gap-2 rounded-full border px-4 py-2 text-sm transition focus:outline-none focus-visible:ring-2 focus-visible:ring-gold disabled:cursor-not-allowed disabled:opacity-40 ${
                    active
                      ? 'border-cabinet bg-cabinet text-[#f6f3ec]'
                      : 'border-rule text-ink hover:bg-paper-deep'
                  }`}
                >
                  {active ? <Check className="h-3.5 w-3.5" /> : null}
                  {interest.label}
                </button>
              </li>
            );
          })}
        </ul>
        <p role="status" className="mt-4 text-sm text-ink-soft">
          {selected.length}{' '}
          {selected.length === 1 ? 'interesse selecionado' : 'interesses selecionados'}
          {selected.length < MIN_INTERESTS ? ` — escolha pelo menos ${MIN_INTERESTS}.` : '.'}
        </p>
      </fieldset>

      {picks.length === 0 ? (
        <p className="mt-8 rounded-2xl border border-dashed border-rule p-10 text-center text-ink-soft">
          Nenhum livro do acervo combina com esses interesses ainda. Tente outras combinações.
        </p>
      ) : (
        <ul className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {picks.map(({ book, reason }) => (
            <li key={book.id}>
              <StoreBookCard
                book={book}
                badge={badgeOf(book)}
                reason={reason}
                onAdd={onAdd}
                onView3D={onView3D}
              />
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
