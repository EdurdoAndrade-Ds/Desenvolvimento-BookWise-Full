import { useCallback, useMemo, useState } from 'react';
import { Minus, MousePointerClick, Plus, RotateCcw, ShoppingBag } from 'lucide-react';
import type { Book } from '../../types/api';
import BookCover from '../BookCover';
import BookViewer3D, { type CameraCommand, type ViewFace } from '../graphics/BookViewer3D';
import SectionHeader from './SectionHeader';
import { useAddToBag, useLendingActions } from './useStoreActions';
import { formatBookFormat, formatCurrency } from '../../lib/format';
import { isWebGLAvailable } from '../../lib/webgl';
import { categoryNames, installmentsOf, isPurchasable, type Badge } from '../../lib/storefront';

const FACES: { id: ViewFace; label: string }[] = [
  { id: 'cover', label: 'Capa' },
  { id: 'spine', label: 'Lombada' },
  { id: 'back', label: 'Contracapa' },
  { id: 'pages', label: 'Páginas' },
];

interface CabinetSectionProps {
  books: Book[];
  selectedId: number | null;
  onSelect: (book: Book) => void;
  badgeOf: (book: Book) => Badge | null;
  onCompleted: () => void;
}

/** Gabinete 3D: gira, aproxima e confere cada face do exemplar antes de levar. */
export default function CabinetSection({
  books,
  selectedId,
  onSelect,
  badgeOf,
  onCompleted,
}: CabinetSectionProps) {
  const book = books.find((item) => item.id === selectedId) ?? books[0];
  const [coverOpen, setCoverOpen] = useState(false);
  const [command, setCommand] = useState<CameraCommand | null>(null);
  const webgl = useMemo(isWebGLAvailable, []);
  const addToBag = useAddToBag();
  const lending = useLendingActions(book, onCompleted);
  const { reset: resetMessages } = lending;

  const send = useCallback(
    (build: (nonce: number) => CameraCommand) =>
      setCommand((current) => build((current?.nonce ?? 0) + 1)),
    [],
  );

  const choose = (next: Book) => {
    setCoverOpen(false);
    setCommand(null);
    resetMessages();
    onSelect(next);
  };

  return (
    <section
      id="visualizador"
      aria-labelledby="visualizador-title"
      className="mx-auto max-w-7xl scroll-mt-24 px-4 py-20 sm:px-6"
    >
      <SectionHeader index="01" label="Gabinete 3D">
        <span id="visualizador-title">
          Folheie com os olhos <em>antes</em> de levar para casa.
        </span>
      </SectionHeader>
      <p className="mt-4 max-w-xl text-ink-soft">
        Gire, aproxime, confira a lombada e o corte das páginas. É o mesmo exemplar que chega até
        você.
      </p>

      {!book ? (
        <p className="mt-10 rounded-2xl border border-dashed border-rule p-12 text-center text-ink-soft">
          Nenhum livro no acervo para exibir no gabinete.
        </p>
      ) : (
        <div className="mt-10 grid grid-cols-1 gap-8 lg:grid-cols-[minmax(0,1.25fr)_minmax(0,1fr)]">
          <div className="min-w-0">
            <div className="relative h-[26rem] overflow-hidden rounded-3xl bg-gradient-to-b from-[#2c1a10] to-[#12100f] shadow-xl sm:h-[34rem]">
              {webgl ? (
                <BookViewer3D
                  book={book}
                  coverOpen={coverOpen}
                  onCoverClick={() => setCoverOpen((open) => !open)}
                  command={command}
                />
              ) : (
                <div className="flex h-full flex-col items-center justify-center gap-4 p-6 text-center text-[#f6f3ec]">
                  <BookCover book={book} className="h-56 w-40 rounded-xl" />
                  <p className="text-sm">
                    Este navegador não expõe WebGL, então mostramos a capa em 2D.
                  </p>
                </div>
              )}
              <p className="pointer-events-none absolute left-1/2 top-4 inline-flex -translate-x-1/2 items-center gap-2 rounded-full bg-black/35 px-4 py-1.5 text-xs text-[#f6f3ec]/85">
                <MousePointerClick className="h-3.5 w-3.5" /> Arraste para girar
              </p>
            </div>

            {webgl ? (
              <div
                role="group"
                aria-label="Controles do visualizador"
                className="mt-4 flex flex-wrap items-center gap-2"
              >
                {FACES.map((face) => (
                  <button
                    key={face.id}
                    type="button"
                    onClick={() => send((nonce) => ({ type: 'face', face: face.id, nonce }))}
                    className="rounded-full border border-rule px-4 py-2 text-sm text-ink transition hover:bg-paper-deep focus:outline-none focus-visible:ring-2 focus-visible:ring-gold"
                  >
                    {face.label}
                  </button>
                ))}
                <span className="mx-1 hidden h-6 w-px bg-rule sm:block" aria-hidden="true" />
                <button
                  type="button"
                  aria-label="Aproximar"
                  onClick={() => send((nonce) => ({ type: 'zoom', factor: 0.8, nonce }))}
                  className="rounded-full border border-rule p-2.5 text-ink hover:bg-paper-deep"
                >
                  <Plus className="h-4 w-4" />
                </button>
                <button
                  type="button"
                  aria-label="Afastar"
                  onClick={() => send((nonce) => ({ type: 'zoom', factor: 1.25, nonce }))}
                  className="rounded-full border border-rule p-2.5 text-ink hover:bg-paper-deep"
                >
                  <Minus className="h-4 w-4" />
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setCoverOpen(false);
                    send((nonce) => ({ type: 'reset', nonce }));
                  }}
                  className="inline-flex items-center gap-2 rounded-full border border-rule px-4 py-2 text-sm text-ink hover:bg-paper-deep"
                >
                  <RotateCcw className="h-4 w-4" /> Restaurar
                </button>
              </div>
            ) : null}

            <div className="mt-8">
              <p className="text-xs font-semibold uppercase tracking-[0.2em] text-ink-soft">
                Escolha um exemplar
              </p>
              <ul className="mt-3 flex gap-3 overflow-x-auto pb-2 [scrollbar-width:thin]">
                {books.map((item) => {
                  const active = item.id === book.id;
                  return (
                    <li key={item.id} className="shrink-0">
                      <button
                        type="button"
                        onClick={() => choose(item)}
                        aria-pressed={active}
                        aria-label={`${item.title}, ${item.author}`}
                        title={item.title}
                        className={`block rounded-lg p-1 transition focus:outline-none focus-visible:ring-2 focus-visible:ring-gold ${
                          active ? 'bg-gold/30 ring-2 ring-gold' : 'opacity-75 hover:opacity-100'
                        }`}
                      >
                        <BookCover
                          book={item}
                          className="h-24 w-16 rounded-md shadow"
                          iconClassName="h-6 w-6"
                        />
                      </button>
                    </li>
                  );
                })}
              </ul>
            </div>
          </div>

          <CabinetDetails
            book={book}
            badge={badgeOf(book)}
            lending={lending}
            onAdd={() => addToBag(book)}
          />
        </div>
      )}
    </section>
  );
}

function CabinetDetails({
  book,
  badge,
  lending,
  onAdd,
}: {
  book: Book;
  badge: Badge | null;
  lending: ReturnType<typeof useLendingActions>;
  onAdd: () => void;
}) {
  const installments = installmentsOf(book.price);
  const category = categoryNames(book)[0] ?? book.genre;
  const stock = book.stock ?? 0;
  const specs: [string, string][] = [
    ['Ano', book.publishedYear === undefined ? '—' : String(book.publishedYear)],
    ['Formato', formatBookFormat(book.format)],
    ['ISBN', book.isbn],
    ['Estoque', book.stock === undefined ? '—' : `${stock} no acervo`],
  ];

  return (
    <div className="rounded-3xl border border-rule bg-paper-card p-7 shadow-sm lg:self-start">
      <div className="flex flex-wrap items-center gap-2">
        {category ? (
          <span className="text-xs font-semibold uppercase tracking-[0.18em] text-gold-deep">
            {category}
          </span>
        ) : null}
        {badge ? (
          <span className="rounded-full bg-cabinet px-2.5 py-1 text-[0.65rem] font-semibold uppercase tracking-wider text-[#f6f3ec]">
            {badge}
          </span>
        ) : null}
      </div>
      <h3 className="mt-3 font-serif text-4xl leading-tight text-ink">{book.title}</h3>
      <p className="mt-1 text-ink-soft">{book.author}</p>

      <dl className="mt-6 grid grid-cols-2 gap-x-6 gap-y-4 border-t border-rule pt-6 text-sm">
        {specs.map(([label, value]) => (
          <div key={label}>
            <dt className="text-xs uppercase tracking-[0.15em] text-ink-soft">{label}</dt>
            <dd className="mt-1 break-all text-ink">{value}</dd>
          </div>
        ))}
      </dl>

      <details className="mt-6 text-sm text-ink-soft">
        <summary className="cursor-pointer font-semibold text-ink">Descrição das faces</summary>
        <p className="mt-2">
          Capa: título “{book.title}” e o nome de {book.author} sobre a cor do exemplar, com a marca
          BookWise. Lombada: na cor do exemplar. Contracapa: marca BookWise e o autor. Páginas:
          bloco em papel creme.
        </p>
      </details>

      <div className="mt-6 border-t border-rule pt-6">
        <p className="font-serif text-3xl text-ink">
          {book.price !== undefined ? formatCurrency(book.price) : 'Preço sob consulta'}
        </p>
        {installments ? (
          <p className="text-sm text-ink-soft">
            ou {installments.count}x de {formatCurrency(installments.value)} sem juros
          </p>
        ) : null}
        <button
          type="button"
          disabled={!isPurchasable(book)}
          onClick={onAdd}
          className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-md bg-cabinet px-4 py-3 text-sm font-semibold text-[#f6f3ec] transition hover:bg-[#3b2f26] disabled:cursor-not-allowed disabled:opacity-40"
        >
          <ShoppingBag className="h-4 w-4" />
          {stock <= 0 ? 'Indisponível' : 'Adicionar à sacola'}
        </button>

        <div className="mt-3 grid grid-cols-2 gap-3">
          <button
            type="button"
            disabled={stock <= 0 || lending.busy !== null}
            onClick={() => void lending.run('borrow')}
            className="rounded-md border border-rule px-3 py-2.5 text-sm font-semibold text-ink hover:bg-paper-deep disabled:cursor-not-allowed disabled:opacity-40"
          >
            {lending.busy === 'borrow' ? 'Processando...' : 'Emprestar agora'}
          </button>
          <button
            type="button"
            disabled={lending.busy !== null}
            onClick={() => void lending.run('reserve')}
            className="rounded-md border border-rule px-3 py-2.5 text-sm font-semibold text-ink hover:bg-paper-deep disabled:cursor-not-allowed disabled:opacity-40"
          >
            {lending.busy === 'reserve' ? 'Processando...' : 'Reservar'}
          </button>
        </div>

        {lending.error ? (
          <p
            role="alert"
            className="mt-4 rounded-md bg-[#f6e7e2] px-3 py-2 text-xs text-[#8a3a27] dark:bg-red-950/40 dark:text-red-300"
          >
            {lending.error}
          </p>
        ) : null}
        {lending.success ? (
          <p
            role="status"
            className="mt-4 rounded-md bg-[#e6efe4] px-3 py-2 text-xs text-[#2f5d3a] dark:bg-emerald-950/40 dark:text-emerald-300"
          >
            {lending.success}
          </p>
        ) : null}
      </div>
    </div>
  );
}
