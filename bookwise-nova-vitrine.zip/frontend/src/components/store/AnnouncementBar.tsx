import { useEffect, useState } from 'react';
import { Pause, Play } from 'lucide-react';
import { FREE_SHIPPING_THRESHOLD } from '../../lib/storefront';
import { formatCurrency } from '../../lib/format';

const MESSAGES = [
  `Frete grátis em compras acima de ${formatCurrency(FREE_SHIPPING_THRESHOLD)}, para todo o Brasil.`,
  '5% de desconto no Pix ou até 4x sem juros.',
  'Troca facilitada em até 30 dias.',
];
const ROTATE_MS = 5000;

function prefersReducedMotion(): boolean {
  return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
}

/** Faixa de avisos que alterna sozinha e pode ser pausada (respeita "reduzir movimento"). */
export default function AnnouncementBar() {
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(prefersReducedMotion);

  useEffect(() => {
    if (paused) return;
    const timer = window.setInterval(
      () => setIndex((value) => (value + 1) % MESSAGES.length),
      ROTATE_MS,
    );
    return () => window.clearInterval(timer);
  }, [paused]);

  return (
    <div className="bg-cabinet text-[#f6f3ec]">
      <div className="mx-auto flex max-w-7xl items-center justify-center gap-4 px-4 py-2 text-xs sm:px-6">
        <p aria-live={paused ? 'polite' : 'off'} className="text-center tracking-wide">
          {MESSAGES[index]}
        </p>
        <button
          type="button"
          onClick={() => setPaused((value) => !value)}
          aria-pressed={paused}
          className="inline-flex shrink-0 items-center gap-1 rounded px-2 py-1 text-[0.7rem] uppercase tracking-wider text-[#f6f3ec]/70 hover:text-white focus:outline-none focus-visible:ring-2 focus-visible:ring-gold"
        >
          {paused ? <Play className="h-3 w-3" /> : <Pause className="h-3 w-3" />}
          {paused ? 'Retomar' : 'Pausar'}
        </button>
      </div>
    </div>
  );
}
