import { useCallback, useState } from 'react';
import type { Book } from '../../types/api';
import { useCart } from '../../cart/useCart';
import { useFeedback } from '../../feedback/useFeedback';
import { useCurrentCustomer } from '../../context/useCurrentCustomer';
import { loansService } from '../../services/loansService';
import { reservationsService } from '../../services/reservationsService';
import { ApiError } from '../../services/http';

/** Coloca o livro na sacola e avisa o resultado com o aviso temporario do projeto. */
export function useAddToBag() {
  const { add } = useCart();
  const { notify } = useFeedback();
  return useCallback(
    (book: Book) => {
      const result = add(book);
      if (result === 'added') notify(`“${book.title}” foi para a sacola.`);
      else if (result === 'limit') notify('Você já levou todos os exemplares em estoque.', 'error');
      else notify('Este livro não está disponível para compra.', 'error');
    },
    [add, notify],
  );
}

export type LendingAction = 'borrow' | 'reserve';

/**
 * Emprestimo e reserva: mesmas chamadas e mesmas mensagens usadas pelo modal
 * BookExperienceModal, para a loja nova nao perder essas funcionalidades.
 */
export function useLendingActions(book: Book | undefined, onCompleted?: () => void) {
  const { customer } = useCurrentCustomer();
  const [busy, setBusy] = useState<LendingAction | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const reset = useCallback(() => {
    setError(null);
    setSuccess(null);
  }, []);

  const run = useCallback(
    async (action: LendingAction) => {
      if (!book) return;
      if (!customer) {
        setSuccess(null);
        setError('Selecione um cliente no cabeçalho para continuar.');
        return;
      }
      setBusy(action);
      setError(null);
      setSuccess(null);
      try {
        if (action === 'reserve') {
          await reservationsService.create({ userId: customer.id, bookId: book.id });
          setSuccess('Reserva realizada com sucesso.');
        } else {
          await loansService.create({
            userId: customer.id,
            items: [{ bookId: book.id, quantity: 1 }],
          });
          setSuccess('Empréstimo realizado com sucesso.');
        }
        onCompleted?.();
      } catch (err) {
        setError(
          err instanceof ApiError && err.status === 409
            ? 'Não há estoque suficiente para concluir esta ação.'
            : err instanceof ApiError
              ? err.message
              : 'Não foi possível concluir a ação.',
        );
      } finally {
        setBusy(null);
      }
    },
    [book, customer, onCompleted],
  );

  return { busy, error, success, run, reset };
}
