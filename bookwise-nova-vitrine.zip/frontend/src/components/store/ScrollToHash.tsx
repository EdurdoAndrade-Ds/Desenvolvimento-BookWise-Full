import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';

/**
 * O BrowserRouter nao rola ate ancoras (#secao) sozinho. Tenta de novo depois de
 * um instante porque a home so monta as secoes depois que o acervo carrega.
 */
export default function ScrollToHash() {
  const { pathname, hash, key } = useLocation();

  useEffect(() => {
    if (!hash) {
      window.scrollTo(0, 0);
      return;
    }
    const id = decodeURIComponent(hash.slice(1));
    const scroll = () => document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
    scroll();
    const retry = window.setTimeout(scroll, 500);
    return () => window.clearTimeout(retry);
  }, [pathname, hash, key]);

  return null;
}
