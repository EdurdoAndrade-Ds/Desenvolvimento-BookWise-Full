import type { Book, Category } from '../../types/api';
import SectionHeader from './SectionHeader';
import { toRoman } from '../../lib/storefront';

const COUNT_WORDS = [
  '',
  'Uma',
  'Duas',
  'Três',
  'Quatro',
  'Cinco',
  'Seis',
  'Sete',
  'Oito',
  'Nove',
  'Dez',
];

interface CategoriesSectionProps {
  categories: Category[];
  books: Book[];
  onPick: (categoryId: string) => void;
}

export default function CategoriesSection({ categories, books, onPick }: CategoriesSectionProps) {
  if (categories.length === 0) return null;

  const word = COUNT_WORDS[categories.length];
  const countOf = (id: number) =>
    books.filter((book) => book.categories?.some((category) => category.id === id)).length;

  return (
    <section
      id="categorias"
      aria-labelledby="categorias-title"
      className="scroll-mt-24 border-y border-rule bg-paper-deep"
    >
      <div className="mx-auto max-w-7xl px-4 py-20 sm:px-6">
        <SectionHeader index="02" label="Categorias">
          <span id="categorias-title">
            {word ? (
              <>
                {word} {categories.length === 1 ? 'estante' : 'estantes'},{' '}
                <em>{word.toLowerCase()} temperamentos.</em>
              </>
            ) : (
              <>
                Estantes para <em>todos os temperamentos.</em>
              </>
            )}
          </span>
        </SectionHeader>

        <ul className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {categories.map((category, index) => {
            const total = countOf(category.id);
            return (
              <li key={category.id}>
                <button
                  type="button"
                  onClick={() => onPick(String(category.id))}
                  className="group flex h-full w-full flex-col rounded-2xl border border-rule bg-paper-card p-6 text-left transition hover:-translate-y-1 hover:border-gold hover:shadow-lg focus:outline-none focus-visible:ring-2 focus-visible:ring-gold"
                >
                  <span className="font-serif text-3xl text-gold">{toRoman(index + 1)}</span>
                  <span className="mt-4 text-xs uppercase tracking-[0.18em] text-ink-soft">
                    {total === 0
                      ? 'Sem títulos ainda'
                      : `${total} ${total === 1 ? 'título' : 'títulos'}`}
                  </span>
                  <span className="mt-1 font-serif text-2xl text-ink">{category.name}</span>
                  {category.description ? (
                    <span className="mt-2 text-sm text-ink-soft">{category.description}</span>
                  ) : null}
                </button>
              </li>
            );
          })}
        </ul>
      </div>
    </section>
  );
}
