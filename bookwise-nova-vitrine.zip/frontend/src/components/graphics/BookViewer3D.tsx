import { Suspense, useEffect, useMemo, useRef } from 'react';
import { Canvas, useFrame, useThree, type ThreeEvent } from '@react-three/fiber';
import { OrbitControls, PerspectiveCamera } from '@react-three/drei';
import { Color, Spherical, Vector3 } from 'three';
import type { Group, Texture } from 'three';
import type { Book } from '../../types/api';
import { facedCoverColor } from '../../graphics/storefrontShelf';
import { createSpineTexture } from '../../graphics/spineTexture';
import {
  createBackCoverTexture,
  createCoverTexture,
  createPageTexture,
} from '../../graphics/coverTexture';

const BOOK_WIDTH = 2.2;
const BOOK_HEIGHT = 3.2;
const BOOK_DEPTH = 0.5;
const COVER_THICKNESS = 0.12;
const COVER_OVERHANG = 0.06;
const HINGE_WIDTH = 0.22;
const COVER_OPEN_ANGLE = -2.3;
const COVER_LERP = 0.12;
const COVER_EPSILON = 0.01;
const FACE_COUNT = 6;
const FRONT_FACE_INDEX = 4;
const BACK_FACE_INDEX = 5;
const SPINE_FACE_INDEX = 1;
const PAGE_EDGE_COLOR = '#f2e9da';
const CAMERA_POSITION: [number, number, number] = [0, 0, 6];
const MIN_ZOOM_DISTANCE = 3.5;
const MAX_ZOOM_DISTANCE = 9;

/** Face do livro que a camera pode enquadrar. */
export type ViewFace = 'cover' | 'spine' | 'back' | 'pages';

/** Comando de camera; `nonce` diferencia comandos repetidos (ex.: dois zooms seguidos). */
export type CameraCommand =
  | { type: 'face'; face: ViewFace; nonce: number }
  | { type: 'zoom'; factor: number; nonce: number }
  | { type: 'reset'; nonce: number };

interface BookViewer3DProps {
  book: Book;
  coverOpen: boolean;
  onCoverClick: () => void;
  /** Opcional: permite que a pagina conduza a camera (faces, zoom, restaurar). */
  command?: CameraCommand | null;
}

// Angulo horizontal da camera para cada face (a lombada fica no lado esquerdo do livro).
const FACE_AZIMUTH: Record<ViewFace, number> = {
  cover: 0,
  spine: -Math.PI / 2,
  back: Math.PI,
  pages: Math.PI / 2,
};
const CAMERA_EASING = 0.15;
const CAMERA_SETTLE = 0.003;

interface OrbitControlsLike {
  target: Vector3;
  update: () => unknown;
}

function clampDistance(distance: number): number {
  return Math.min(MAX_ZOOM_DISTANCE, Math.max(MIN_ZOOM_DISTANCE, distance));
}

/** Anima a camera ate o enquadramento pedido, sem brigar com o arraste do usuario. */
function CameraRig({ command }: { command: CameraCommand | null }) {
  const camera = useThree((state) => state.camera);
  const controls = useThree((state) => state.controls) as unknown as OrbitControlsLike | null;
  const goal = useRef<Spherical | null>(null);

  useEffect(() => {
    if (!command || !controls) return;
    const current = new Spherical().setFromVector3(
      new Vector3().copy(camera.position).sub(controls.target),
    );
    if (command.type === 'zoom') {
      goal.current = new Spherical(
        clampDistance(current.radius * command.factor),
        current.phi,
        current.theta,
      );
    } else if (command.type === 'face') {
      goal.current = new Spherical(current.radius, Math.PI / 2, FACE_AZIMUTH[command.face]);
    } else {
      goal.current = new Spherical(CAMERA_POSITION[2], Math.PI / 2, 0);
    }
  }, [command, camera, controls]);

  useFrame(() => {
    const target = goal.current;
    if (!target || !controls) return;
    const current = new Spherical().setFromVector3(
      new Vector3().copy(camera.position).sub(controls.target),
    );
    const deltaTheta = Math.atan2(
      Math.sin(target.theta - current.theta),
      Math.cos(target.theta - current.theta),
    );
    const deltaPhi = target.phi - current.phi;
    const deltaRadius = target.radius - current.radius;

    current.theta += deltaTheta * CAMERA_EASING;
    current.phi += deltaPhi * CAMERA_EASING;
    current.radius += deltaRadius * CAMERA_EASING;
    camera.position.copy(new Vector3().setFromSpherical(current).add(controls.target));
    camera.lookAt(controls.target);
    controls.update();

    if (
      Math.abs(deltaTheta) < CAMERA_SETTLE &&
      Math.abs(deltaPhi) < CAMERA_SETTLE &&
      Math.abs(deltaRadius) < CAMERA_SETTLE
    ) {
      goal.current = null;
    }
  });

  return null;
}

/**
 * Livro em destaque: arraste para girar, use o scroll para aproximar e clique
 * na capa para abri-la.
 */
export default function BookViewer3D({
  book,
  coverOpen,
  onCoverClick,
  command = null,
}: BookViewer3DProps) {
  return (
    <Canvas dpr={[1, 2]}>
      <PerspectiveCamera makeDefault position={CAMERA_POSITION} fov={42} />
      <OrbitControls
        makeDefault
        enablePan={false}
        minDistance={MIN_ZOOM_DISTANCE}
        maxDistance={MAX_ZOOM_DISTANCE}
      />
      <CameraRig command={command} />
      <ambientLight intensity={1.2} />
      <directionalLight position={[4, 5, 6]} intensity={2} />
      <pointLight position={[-4, 1, 4]} intensity={2.5} color="#d7ad88" distance={20} />
      <Suspense fallback={null}>
        <OpenableBook book={book} coverOpen={coverOpen} onCoverClick={onCoverClick} />
      </Suspense>
    </Canvas>
  );
}

/** Miolo em tom de papel; lombada e contracapa recebem a cor do livro. */
function faceColor(face: number, color: string): string {
  if (face === SPINE_FACE_INDEX) return color;
  if (face === FRONT_FACE_INDEX || face === BACK_FACE_INDEX) return '#ffffff';
  return PAGE_EDGE_COLOR;
}

/** Tom mais fechado da cor do livro para bordas, verso da capa e dobradica. */
function shade(color: string, factor: number): string {
  return `#${new Color(color).multiplyScalar(factor).getHexString()}`;
}

/** Capa com volume: face externa recebe a arte e o resto (bordas e verso) fica pintado. */
function coverFaceColor(face: number, color: string): string {
  if (face === FRONT_FACE_INDEX) return '#ffffff';
  return shade(color, 0.7);
}

function faceTexture(
  face: number,
  pageTexture: Texture,
  backCoverTexture: Texture,
): Texture | null {
  if (face === FRONT_FACE_INDEX) return pageTexture;
  if (face === BACK_FACE_INDEX) return backCoverTexture;
  return null;
}

function OpenableBook({ book, coverOpen, onCoverClick }: Omit<BookViewer3DProps, 'command'>) {
  const hinge = useRef<Group>(null);
  const color = useMemo(() => facedCoverColor(book), [book]);
  const coverTexture = useMemo(
    () => createCoverTexture({ title: book.title, author: book.author, background: color }),
    [book.title, book.author, color],
  );
  const pageTexture = useMemo(
    () => createPageTexture({ title: book.title, author: book.author, background: color }),
    [book.title, book.author, color],
  );
  const backCoverTexture = useMemo(
    () => createBackCoverTexture({ title: book.title, author: book.author, background: color }),
    [book.title, book.author, color],
  );

  const spineTexture = useMemo(
    () =>
      createSpineTexture({
        title: book.title,
        author: book.author,
        background: shade(color, 0.55),
      }),
    [book.title, book.author, color],
  );

  useEffect(
    () => () => {
      coverTexture.dispose();
      pageTexture.dispose();
      backCoverTexture.dispose();
      spineTexture.dispose();
    },
    [coverTexture, pageTexture, backCoverTexture, spineTexture],
  );

  useFrame(() => {
    if (!hinge.current) return;
    const target = coverOpen ? COVER_OPEN_ANGLE : 0;
    hinge.current.rotation.y += (target - hinge.current.rotation.y) * COVER_LERP;
  });

  const handleCoverClick = (event: ThreeEvent<MouseEvent>) => {
    event.stopPropagation();
    onCoverClick();
  };

  return (
    <group>
      <mesh>
        <boxGeometry args={[BOOK_WIDTH, BOOK_HEIGHT, BOOK_DEPTH]} />
        {Array.from({ length: FACE_COUNT }, (_, face) => (
          <meshStandardMaterial
            key={face}
            attach={`material-${face}`}
            color={faceColor(face, color)}
            map={faceTexture(face, pageTexture, backCoverTexture)}
            roughness={0.75}
          />
        ))}
      </mesh>

      <mesh position={[-BOOK_WIDTH / 2, 0, 0]}>
        <boxGeometry
          args={[HINGE_WIDTH, BOOK_HEIGHT + COVER_OVERHANG, BOOK_DEPTH + COVER_THICKNESS * 2]}
        />
        {Array.from({ length: FACE_COUNT }, (_, face) => (
          <meshStandardMaterial
            key={face}
            attach={`material-${face}`}
            color={face === SPINE_FACE_INDEX ? '#ffffff' : shade(color, 0.55)}
            map={face === SPINE_FACE_INDEX ? spineTexture : null}
            roughness={1}
          />
        ))}
      </mesh>

      <group
        ref={hinge}
        position={[-BOOK_WIDTH / 2, 0, BOOK_DEPTH / 2 + COVER_EPSILON + COVER_THICKNESS / 2]}
      >
        <mesh position={[BOOK_WIDTH / 2, 0, 0]} onClick={handleCoverClick}>
          <boxGeometry args={[BOOK_WIDTH, BOOK_HEIGHT + COVER_OVERHANG, COVER_THICKNESS]} />
          {Array.from({ length: FACE_COUNT }, (_, face) => (
            <meshStandardMaterial
              key={face}
              attach={`material-${face}`}
              color={coverFaceColor(face, color)}
              map={face === FRONT_FACE_INDEX ? coverTexture : null}
              roughness={face === FRONT_FACE_INDEX ? 0.55 : 0.8}
            />
          ))}
        </mesh>
      </group>
    </group>
  );
}
