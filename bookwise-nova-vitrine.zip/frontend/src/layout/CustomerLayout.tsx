import { useEffect, useState } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import { CurrentCustomerProvider } from '../context/CurrentCustomerContext';
import { CartProvider } from '../cart/CartProvider';
import AnnouncementBar from '../components/store/AnnouncementBar';
import StoreHeader from '../components/store/StoreHeader';
import StoreFooter from '../components/store/StoreFooter';
import CartDrawer from '../components/store/CartDrawer';
import ScrollToHash from '../components/store/ScrollToHash';
import { categoriesService } from '../services/categoriesService';
import type { Category } from '../types/api';

export default function CustomerLayout() {
  const { pathname } = useLocation();
  const [categories, setCategories] = useState<Category[]>([]);

  useEffect(() => {
    categoriesService
      .listAll()
      .then(setCategories)
      .catch(() => setCategories([]));
  }, []);

  // A home ocupa a largura toda (secoes em faixa); as demais paginas mantem a coluna centralizada.
  const isHome = pathname === '/';

  return (
    <CurrentCustomerProvider>
      <CartProvider>
        <div className="flex min-h-full flex-col bg-paper text-ink">
          <a
            href="#conteudo"
            className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:rounded-md focus:bg-cabinet focus:px-4 focus:py-2 focus:text-sm focus:text-white"
          >
            Pular para o conteúdo
          </a>
          <AnnouncementBar />
          <StoreHeader />
          <ScrollToHash />
          <main id="conteudo" className="flex-1">
            {isHome ? (
              <Outlet />
            ) : (
              <div className="mx-auto w-full max-w-6xl px-4 py-8 sm:px-6 lg:px-10">
                <Outlet />
              </div>
            )}
          </main>
          <StoreFooter categories={categories} />
          <CartDrawer />
        </div>
      </CartProvider>
    </CurrentCustomerProvider>
  );
}
