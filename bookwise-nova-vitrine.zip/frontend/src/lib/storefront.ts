import type { Book, BookRanking } from '../types/api';

// Regras de vitrine da loja. Tudo aqui e puro (sem React e sem rede): os dados vem
// da API existente e este modulo apenas os organiza para a apresentacao.

export const FREE_SHIPPING_THRESHOLD = 199;
export const PRICE_CAP = 100;
const LAUNCH_WINDOW_DAYS = 45;
const LAUNCH_LIMIT = 5;
const CLASSIC_BEFORE_YEAR = 1960;

export interface Installments {
  count: number;
  value: number;
}

/** Parcelamento exibido na vitrine: 3x ate R$ 59,99 e 4x a partir de R$ 60. */
export function installmentsOf(price?: number): Installments | null {
  if (price === undefined || price === null || price <= 0) return null;
  const count = price >= 60 ? 4 : 3;
  return { count, value: Math.round((price / count) * 100) / 100 };
}

/** Minusculas e sem acentos, para comparar textos sem se importar com a grafia. */
export function normalize(text: string): string {
  return text
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase();
}

const ROMAN: [number, string][] = [
  [10, 'X'],
  [9, 'IX'],
  [5, 'V'],
  [4, 'IV'],
  [1, 'I'],
];

export function toRoman(value: number): string {
  let rest = Math.max(1, Math.floor(value));
  let result = '';
  for (const [amount, symbol] of ROMAN) {
    while (rest >= amount) {
      result += symbol;
      rest -= amount;
    }
  }
  return result;
}

export function categoryNames(book: Book): string[] {
  return (book.categories ?? []).map((category) => category.name);
}

export function isPurchasable(book: Book): boolean {
  return book.price !== undefined && book.price !== null && book.price > 0 && (book.stock ?? 0) > 0;
}

// ---------------------------------------------------------------- filtros

export type SortKey = 'relevance' | 'price-asc' | 'price-desc';

export interface LibraryFilters {
  query: string;
  categoryId: string;
  underCap: boolean;
  inStock: boolean;
}

export function filterBooks(books: Book[], filters: LibraryFilters): Book[] {
  const query = normalize(filters.query.trim());
  return books.filter((book) => {
    if (
      filters.categoryId &&
      !book.categories?.some((category) => category.id === Number(filters.categoryId))
    ) {
      return false;
    }
    if (filters.underCap && !(book.price !== undefined && book.price <= PRICE_CAP)) return false;
    if (filters.inStock && (book.stock ?? 0) <= 0) return false;
    if (!query) return true;
    const haystack = normalize(
      [book.title, book.author, book.isbn, book.genre ?? '', ...categoryNames(book)].join(' '),
    );
    return haystack.includes(query);
  });
}

export function sortBooks(books: Book[], key: SortKey): Book[] {
  if (key === 'relevance') return books;
  const direction = key === 'price-asc' ? 1 : -1;
  return [...books].sort((a, b) => {
    // Livros sem preco vao sempre para o fim, em qualquer direcao.
    if (a.price === undefined && b.price === undefined) return 0;
    if (a.price === undefined) return 1;
    if (b.price === undefined) return -1;
    return (a.price - b.price) * direction;
  });
}

// ----------------------------------------------------- destaques e selos

export function newestFirst(books: Book[]): Book[] {
  return [...books].sort((a, b) => {
    const first = a.createdAt ?? '';
    const second = b.createdAt ?? '';
    if (first === second) return b.id - a.id;
    return second.localeCompare(first);
  });
}

/**
 * Ordena pelo ranking de emprestimos (relatorio ja existente na API) e mantem os
 * demais livros na ordem original. Sem ranking, preserva a ordem recebida.
 */
export function orderByPopularity(books: Book[], ranking: BookRanking[]): Book[] {
  const position = new Map<number, number>();
  ranking.forEach((entry, index) => position.set(entry.bookId, index));
  const ranked = books
    .filter((book) => position.has(book.id))
    .sort((a, b) => (position.get(a.id) ?? 0) - (position.get(b.id) ?? 0));
  const rest = books.filter((book) => !position.has(book.id));
  return [...ranked, ...rest];
}

/**
 * Lancamentos sao os cadastrados recentemente. Se o acervo inteiro e recente
 * (caso comum de base recem-semeada) nenhum recebe selo, porque nao haveria
 * diferenca real entre os livros.
 */
export function launchIds(books: Book[], now: number = Date.now()): Set<number> {
  const windowMs = LAUNCH_WINDOW_DAYS * 24 * 60 * 60 * 1000;
  const recent = newestFirst(books).filter((book) => {
    const created = book.createdAt ? Date.parse(book.createdAt) : Number.NaN;
    return !Number.isNaN(created) && now - created <= windowMs;
  });
  if (recent.length === 0 || recent.length === books.length) return new Set();
  return new Set(recent.slice(0, LAUNCH_LIMIT).map((book) => book.id));
}

export type Badge = 'Mais procurado' | 'Lançamento';

export function badgeFor(book: Book, popular: Set<number>, launches: Set<number>): Badge | null {
  if (popular.has(book.id)) return 'Mais procurado';
  if (launches.has(book.id)) return 'Lançamento';
  return null;
}

// ------------------------------------------------------- recomendacoes

export interface Interest {
  id: string;
  label: string;
  /** Prefixos de palavras (sem acento) buscados em categorias, genero, titulo e autor. */
  keywords: string[];
  /** Considera tambem a idade da obra. */
  classic?: boolean;
  reason: string;
}

export const MIN_INTERESTS = 3;
export const MAX_INTERESTS = 5;

export const INTERESTS: Interest[] = [
  {
    id: 'upside-down',
    label: 'histórias que viram o mundo de cabeça para baixo',
    keywords: ['ficcao', 'fantas', 'distop', 'cientifica', 'sci'],
    reason: 'Para quem quer histórias que viram o mundo de cabeça para baixo.',
  },
  {
    id: 'ideas',
    label: 'ideias para pensar a vida',
    keywords: ['filosof', 'naoficcao', 'historia', 'ensaio', 'psicolog', 'sociolog', 'estoic'],
    reason: 'Para quem procura ideias para pensar a vida.',
  },
  {
    id: 'love',
    label: 'amores difíceis e bem escritos',
    keywords: ['romance', 'amor', 'poesia', 'cartas'],
    reason: 'Para quem gosta de amores difíceis e bem escritos.',
  },
  {
    id: 'mystery',
    label: 'mistérios que pedem atenção',
    keywords: ['misterio', 'suspense', 'policial', 'crime', 'thriller', 'detetive'],
    reason: 'Para quem aprecia mistérios que pedem atenção.',
  },
  {
    id: 'brazil',
    label: 'o Brasil visto de perto',
    keywords: ['brasil', 'brasileir', 'machado', 'nordest', 'amazon'],
    reason: 'Para quem quer ver o Brasil de perto.',
  },
  {
    id: 'worlds',
    label: 'mundos que não existem (ainda)',
    keywords: ['fantas', 'cientifica', 'sci', 'magia', 'dragao', 'espaco', 'futuro'],
    reason: 'Para quem quer visitar mundos que não existem (ainda).',
  },
  {
    id: 'routine',
    label: 'pequenas mudanças de rotina',
    keywords: ['desenvolvimento', 'habito', 'produtiv', 'rotina', 'autoajuda', 'mindful', 'pausa'],
    reason: 'Para quem busca pequenas mudanças de rotina.',
  },
  {
    id: 'classics',
    label: 'os clássicos que sempre adiei',
    keywords: ['classic'],
    classic: true,
    reason: 'Para quem quer, enfim, ler os clássicos que sempre adiou.',
  },
];

export const DEFAULT_INTERESTS = ['upside-down', 'love', 'routine'];

function tokens(text: string): string[] {
  return normalize(text)
    .replace(/nao[-\s]?ficcao/g, 'naoficcao')
    .split(/[^a-z0-9]+/)
    .filter(Boolean);
}

function matches(words: string[], keywords: string[]): boolean {
  return keywords.some((keyword) => words.some((word) => word.startsWith(keyword)));
}

function scoreFor(book: Book, interest: Interest): number {
  const categoryWords = tokens([...categoryNames(book), book.genre ?? ''].join(' '));
  const textWords = tokens(`${book.title} ${book.author}`);
  let score = 0;
  if (matches(categoryWords, interest.keywords)) score += 3;
  if (matches(textWords, interest.keywords)) score += 1;
  if (
    interest.classic &&
    book.publishedYear !== undefined &&
    book.publishedYear < CLASSIC_BEFORE_YEAR
  ) {
    score += 3;
  }
  return score;
}

export interface Recommendation {
  book: Book;
  score: number;
  reason: string;
}

export function recommend(
  books: Book[],
  selectedIds: string[],
  limit: number = 4,
): Recommendation[] {
  const selected = INTERESTS.filter((interest) => selectedIds.includes(interest.id));
  if (selected.length === 0) return [];

  return books
    .map((book) => {
      let total = 0;
      let best = { score: 0, reason: '' };
      for (const interest of selected) {
        const score = scoreFor(book, interest);
        total += score;
        if (score > best.score) best = { score, reason: interest.reason };
      }
      return { book, score: total, reason: best.reason };
    })
    .filter((entry) => entry.score > 0)
    .sort((a, b) => {
      if (b.score !== a.score) return b.score - a.score;
      const stockA = (a.book.stock ?? 0) > 0 ? 1 : 0;
      const stockB = (b.book.stock ?? 0) > 0 ? 1 : 0;
      if (stockB !== stockA) return stockB - stockA;
      return a.book.id - b.book.id;
    })
    .slice(0, limit);
}
