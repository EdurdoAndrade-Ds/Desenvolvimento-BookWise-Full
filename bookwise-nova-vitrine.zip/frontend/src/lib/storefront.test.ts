import { describe, expect, it } from 'vitest';
import type { Book } from '../types/api';
import {
  badgeFor,
  filterBooks,
  installmentsOf,
  isPurchasable,
  launchIds,
  normalize,
  orderByPopularity,
  recommend,
  sortBooks,
  toRoman,
} from './storefront';

function book(overrides: Partial<Book> & { id: number }): Book {
  return {
    title: `Livro ${overrides.id}`,
    author: 'Autor',
    isbn: `isbn-${overrides.id}`,
    format: 'PHYSICAL',
    price: 50,
    stock: 3,
    ...overrides,
  };
}

describe('installmentsOf', () => {
  it('usa 3x abaixo de R$ 60 e 4x a partir dai, arredondando a parcela', () => {
    expect(installmentsOf(44.9)).toEqual({ count: 3, value: 14.97 });
    expect(installmentsOf(64.9)).toEqual({ count: 4, value: 16.23 });
    expect(installmentsOf(60)).toEqual({ count: 4, value: 15 });
  });

  it('nao parcela livro sem preco valido', () => {
    expect(installmentsOf(undefined)).toBeNull();
    expect(installmentsOf(0)).toBeNull();
  });
});

describe('normalize e toRoman', () => {
  it('remove acentos e caixa', () => {
    expect(normalize('Ficção Científica')).toBe('ficcao cientifica');
  });

  it('converte numeros em romanos', () => {
    expect([1, 4, 6, 9, 10, 12].map(toRoman)).toEqual(['I', 'IV', 'VI', 'IX', 'X', 'XII']);
  });
});

describe('filterBooks', () => {
  const books = [
    book({ id: 1, title: 'Dom Casmurro', author: 'Machado de Assis', price: 44.9 }),
    book({
      id: 2,
      title: 'Duna',
      author: 'Frank Herbert',
      price: 120,
      categories: [{ id: 7, name: 'Ficção Científica' }],
    }),
    book({ id: 3, title: 'Esgotado', price: 30, stock: 0 }),
  ];
  const base = { query: '', categoryId: '', underCap: false, inStock: false };

  it('busca por titulo, autor e categoria ignorando acentos', () => {
    expect(filterBooks(books, { ...base, query: 'MACHADO' }).map((b) => b.id)).toEqual([1]);
    expect(filterBooks(books, { ...base, query: 'ficcao cientifica' }).map((b) => b.id)).toEqual([
      2,
    ]);
  });

  it('aplica categoria, teto de preco e estoque', () => {
    expect(filterBooks(books, { ...base, categoryId: '7' }).map((b) => b.id)).toEqual([2]);
    expect(filterBooks(books, { ...base, underCap: true }).map((b) => b.id)).toEqual([1, 3]);
    expect(filterBooks(books, { ...base, inStock: true }).map((b) => b.id)).toEqual([1, 2]);
  });
});

describe('sortBooks', () => {
  const books = [
    book({ id: 1, price: 50 }),
    book({ id: 2, price: undefined }),
    book({ id: 3, price: 20 }),
  ];

  it('ordena por preco mantendo os sem preco no fim nas duas direcoes', () => {
    expect(sortBooks(books, 'price-asc').map((b) => b.id)).toEqual([3, 1, 2]);
    expect(sortBooks(books, 'price-desc').map((b) => b.id)).toEqual([1, 3, 2]);
  });

  it('preserva a ordem original em relevancia', () => {
    expect(sortBooks(books, 'relevance')).toBe(books);
  });
});

describe('popularidade e lancamentos', () => {
  it('coloca primeiro os livros do ranking e preserva os demais', () => {
    const books = [book({ id: 1 }), book({ id: 2 }), book({ id: 3 })];
    const ranking = [
      { bookId: 3, title: '', author: '', loanCount: 9, unitsLoaned: 9, openLoans: 0 },
      { bookId: 99, title: '', author: '', loanCount: 5, unitsLoaned: 5, openLoans: 0 },
    ];
    expect(orderByPopularity(books, ranking).map((b) => b.id)).toEqual([3, 1, 2]);
  });

  it('nao marca lancamento quando o acervo inteiro e recente', () => {
    const now = Date.parse('2026-11-23T12:00:00Z');
    const books = [
      book({ id: 1, createdAt: '2026-11-20T10:00:00Z' }),
      book({ id: 2, createdAt: '2026-11-21T10:00:00Z' }),
    ];
    expect(launchIds(books, now).size).toBe(0);
  });

  it('marca apenas os recentes quando ha diferenca real', () => {
    const now = Date.parse('2026-11-23T12:00:00Z');
    const books = [
      book({ id: 1, createdAt: '2025-01-01T10:00:00Z' }),
      book({ id: 2, createdAt: '2026-11-21T10:00:00Z' }),
    ];
    const launches = launchIds(books, now);
    expect([...launches]).toEqual([2]);
    expect(badgeFor(books[1], new Set(), launches)).toBe('Lançamento');
    expect(badgeFor(books[1], new Set([2]), launches)).toBe('Mais procurado');
    expect(badgeFor(books[0], new Set(), launches)).toBeNull();
  });
});

describe('isPurchasable', () => {
  it('exige preco positivo e estoque', () => {
    expect(isPurchasable(book({ id: 1 }))).toBe(true);
    expect(isPurchasable(book({ id: 2, price: undefined }))).toBe(false);
    expect(isPurchasable(book({ id: 3, stock: 0 }))).toBe(false);
  });
});

describe('recommend', () => {
  const books = [
    book({
      id: 1,
      title: 'Fundação',
      categories: [{ id: 1, name: 'Ficção Científica' }],
    }),
    book({
      id: 2,
      title: 'Sapiens',
      categories: [{ id: 2, name: 'Não-Ficção' }],
    }),
    book({
      id: 3,
      title: 'Dom Casmurro',
      author: 'Machado de Assis',
      publishedYear: 1899,
    }),
  ];

  it('nao confunde Nao-Ficcao com Ficcao', () => {
    const result = recommend(books, ['upside-down']).map((entry) => entry.book.id);
    expect(result).toContain(1);
    expect(result).not.toContain(2);
  });

  it('reconhece classicos pela idade da obra', () => {
    expect(recommend(books, ['classics']).map((entry) => entry.book.id)).toEqual([3]);
  });

  it('retorna vazio sem interesses ou sem correspondencia', () => {
    expect(recommend(books, [])).toEqual([]);
    expect(recommend([book({ id: 9 })], ['mystery'])).toEqual([]);
  });

  it('usa a razao do interesse que mais pesou', () => {
    const [first] = recommend(books, ['upside-down', 'worlds']);
    expect(first.book.id).toBe(1);
    expect(first.reason).not.toBe('');
  });
});
